<!DOCTYPE html>

<html>


<head>

</head>
<body>
    <?php

function areafunc($length, $width) {
    $area = $length * $width;
    return $area;
}
$arearesult = areafunc(7, 9);
echo $arearesult;

?>
</body>



</html>