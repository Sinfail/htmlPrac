<!DOCTYPE html>
<html>

<head>

</head>

<body>

<?php 

//definitions

$var1 = 99;

$var2 = 99.888;

$var3 = "this is a string";

$var4 = True;

$var5 = NULL;

echo "\$var1" . " is of " .  gettype($var1) . " data type, and its value is " . $var1. "<br>";
echo "\$var2" . " is of " .  gettype($var2) . " data type, and its value is " . $var2. "<br>";
echo "\$var3" . " is of " .  gettype($var3) . " data type, and its value is " . $var3. "<br>";
echo "\$var4" . " is of " .  gettype($var4) . " data type, and its value is " . $var4.    "<br>";
echo "\$var5" . " is of " .  gettype($var5) . " data type, and its value is " . $var5. "<br>";















?>





</body>



</html>